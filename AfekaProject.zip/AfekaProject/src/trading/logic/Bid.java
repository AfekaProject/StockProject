package trading.logic;



public class Bid{
	
	
	String stockName;
	int id;
	int amount;
	int price;
	
	public Bid (String stockName, int amount , int price){
		this.stockName = stockName;
		this.amount = amount;
		this.price = price;
	}
	
	
		
		
		

}