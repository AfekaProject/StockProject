package trading.logic;

public class Ask {

}
